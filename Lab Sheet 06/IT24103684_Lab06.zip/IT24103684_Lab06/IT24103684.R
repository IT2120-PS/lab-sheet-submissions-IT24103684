setwd("C:\\Users\\PC\\Desktop\\IT24103684_Lab06")
getwd()

#1

#Here, random variable X has binomial distribution with n=50 and p=0.85

pbinom(46, 50, 0.85,lower.tail = FALSE)



#2
#Here, random variable X is Number of calls received in given day
# The distribution type in poisson distribution
dpois(15, 12)
