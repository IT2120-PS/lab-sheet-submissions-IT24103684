setwd("C:\\Users\\PC\\Desktop\\IT24103684_Lab05")
getwd()

Delivery_Times <- read.csv("Exercise - Lab 05.txt")

breaks <- seq(20, 70, length.out = 10)
hist(Delivery_Times$Delivery_Time,
     breaks = breaks,
     right = FALSE,                      
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     col = "lightblue"
       )

#If the histogram is skewed to the right (positive skew), the tail is on the right side, that means most delivery times are shorter, but there are some larger values.

#If the histogram is skewed to the left (negative skew), the tail is on the left side, it indicating most deliveries are longer with a few fast deliveries.

#If the histogram is roughly symmetric, the distribution of delivery times is balanced with a similar number of fast and slow deliveries.

#If the histogram forms a bell-shaped curve then it may resemble a normal distribution.



breaks <- seq(20, 70, length.out = 10)

hist_data <- hist(Delivery_Times$Delivery_Time,
                  breaks = breaks,
                  right = FALSE,
                  plot = FALSE)

cum_freq <- cumsum(hist_data$counts)

new <- numeric(length = length(hist_data$breaks))

for(i in 1:length(hist_data$breaks)) {
  if(i == 1) {
    new[i] <- 0
  } else {
    new[i] <- cum_freq[i-1]
  }
}

plot(hist_data$breaks, new, type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     col = "blue", pch = 16)

cbind(Upper = hist_data$breaks, CumFreq = new)



