setwd("C:\\Users\\it24103684\\Desktop\\IT24103684_Lab05")
getwd()

Delivery_Times <- read.csv("Exercise - Lab 05.txt")

breaks <- seq(20, 70, length.out = 10)
hist(Delivery_Times$Delivery_Time,
     breaks = breaks,
     right = FALSE,                      
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     col = "lightblue"
       )

#If the histogram is skewed to the right (positive skew), the tail is on the right side, that means most delivery times are shorter, but there are some larger values.

#If the histogram is skewed to the left (negative skew), the tail is on the left side, it indicating most deliveries are longer with a few fast deliveries.

#If the histogram is roughly symmetric, the distribution of delivery times is balanced with a similar number of fast and slow deliveries.

#If the histogram forms a bell-shaped curve then it may resemble a normal distribution.


breaks <- seq(20, 70, length.out = 10)
hist_data <- hist(Delivery_Times$Delivery_Time,
                  breaks = breaks,
                  right = FALSE,
                  plot = FALSE)


cum_freq <- cumsum(hist_data$counts)
plot(hist_data$breaks[-1], cum_freq, type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     col = "blue", pch = 16)


