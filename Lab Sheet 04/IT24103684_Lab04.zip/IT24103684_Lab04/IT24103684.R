setwd("C:\\Users\\IT24103684\\Desktop\\IT24103684_Lab04")
getwd()

data <- read.csv("Exercise.txt")
head(data)

str(data)

boxplot(data$Sales,
       main="Boxplot of Sales",
       ylab="Sales",
       col="lightblue")

fivenum(data$Advertising, na.rm = TRUE)

IQR_of_advertising <- IQR(data$Advertising, na.rm = TRUE)
IQR_of_advertising

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25, na.rm = TRUE)
  Q3 <- quantile(x, 0.75, na.rm = TRUE)
  IQR_value <- IQR(x, na.rm = TRUE)
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}
outliers_years <- find_outliers(data$Years)
outliers_years
